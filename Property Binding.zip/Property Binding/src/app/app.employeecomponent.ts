import {Component} from '@angular/core';

@Component({
	selector:'<my-component></my-component>',
	templateUrl:'./app.employeecomponent.html'
})

export class AppEmployeeComponent{
		status:boolean=false;
		onClick():void{
			console.log("WELCOME TO EVENT");
			alert("Hello World");
		}
		show():void{
			this.status=!this.status;
		}
}


