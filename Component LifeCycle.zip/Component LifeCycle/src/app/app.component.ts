import { Component,OnInit,Input,SimpleChanges,OnDestroy,OnChanges } from '@angular/core';

@Component({
  selector: 'my-app',templateUrl:'./app.component.html',
})
export class AppComponent implements OnInit,OnDestroy 
{
	//@Input()	title:string;
	//@Input()	content:string;
	constructor(){}
	
	ngOnDestroy():void
	{
		console.log('Component Destroy');
	}
	
	ngOnInit():void
	{
		console.log('Component Init');
	}
	
}
